//get the elements from html
var taskInput = document.getElementById('new-task');
var addbutton = document.getElementsByTagName('button')[0];
var incompleteTaskHolder = document.getElementById('incomplete-tasks')
var completeTaskHolder = document.getElementById('completed-tasks');
// write the function to create the elements dynamicaly and append it to li element
var createTaskElement = function(taskString){
    //listElement
    var listitem = document.createElement('li');
    //label
    var label = document.createElement('label');
    //checkbox
    var checkBox = document.createElement('input');
    //textbox
    var editTextInput = document.createElement('input');
    //editbutton
    var editButton = document.createElement('button');
    //deletebutton
    var deletebutton = document.createElement('button');
    //assigning type for checkbox and textbox
    checkBox.type = "checkbox";
    editTextInput.type = "text";

    //adding text to the label
    label.innerText = taskString;
    //adding text inside button and assigning className for edit and delete button
    editButton.innerText = "Edit";
    editButton.className = "edit";
    deletebutton.innerText = "Delete";
    deletebutton.className = "delete";
    // as seen above all the elements are created now we have to append child elements to the listitem(<li>)
    listitem.appendChild(checkBox);
    listitem.appendChild(label);
    listitem.appendChild(editTextInput);
    listitem.appendChild(editButton);
    listitem.appendChild(deletebutton);
    //finally return listitem
    return listitem;

}
//addTask function will add the listitem to incomplete section as shown below 
var addTask = function(){
    // pass the taskInput value to the createTaskElement function using taskInput.value property
    var listItem = createTaskElement(taskInput.value);
    //append the listItem to incompleteTaskHolder 
    var incomplete = incompleteTaskHolder.appendChild(listItem);
    bindTaskEvents(listItem, taskCompleted);

}
var editTask = function(){debugger;
    console.log('edit function')
    var listItem = this.parentNode;

    var editInput = listItem.querySelector("input[type=text]");

    var label = listItem.querySelector("label");

    var containsClass = listItem.classList.contains('editMode')

    if(containsClass){
        label.innerText = editInput.value;
    }
    else{
        editInput.value = label.innerText;
    }

    listItem.classList.toggle("editMode")
}

var deleteTask = function(){
    console.log('delete ')
    var listItem = this.parentNode;
    var ul = listItem.parentNode;

    ul.removeChild(listItem);

}
var taskIncomplete = function(){
    var listItem = this.parentNode;
    incompleteTaskHolder.appendChild(listItem);
    bindTaskEvents(listItem,taskCompleted);

}
var taskCompleted = function(){
    var listItem = this.parentNode;
    completeTaskHolder.appendChild(listItem);
    bindTaskEvents(listItem,taskIncomplete)

}

//the above function was only for creating elements and appending it to 'li' element

var bindTaskEvents = function(taskListItem, checkBoxEventHandler) {
    console.log("Bind list item events");
    //select taskListItem's children
    var checkBox = taskListItem.querySelector("input[type=checkbox]");
    var editButton = taskListItem.querySelector("button.edit");
    var deleteButton = taskListItem.querySelector("button.delete");



    //bind deleteTask to delete button
    deleteButton.onclick = deleteTask;

    //checkbox functionality


    checkBox.onchange = checkBoxEventHandler;

    editButton.onclick = editTask;
   
}



// add the click event listener on addbutton
addbutton.addEventListener('click', addTask);

for(var i = 0; i< incompleteTaskHolder.children.length; i++){debugger;

    bindTaskEvents(incompleteTaskHolder.children[i], taskCompleted)
}

for(var i = 0; i< completeTaskHolder.children.length; i++){
    bindTaskEvents(completeTaskHolder.children[i], taskIncomplete)
}