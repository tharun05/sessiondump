/*
DOM MANIPULATION
EVENT HANDLERS AND EVENT LISTERNERS
DOM METHODS AND ITS PROPERTIES

1) get the elements from the document object
2) append the li elements to ul list
3) append the ul to incomplete section
*/


var taskInput = document.getElementById('new-task');
var addbutton = document.getElementsByTagName('button')[0];
var incompleteTaskHolder = document.getElementById('incomplete-tasks');
var completeTaskHolder = document.getElementById('completed-tasks');


var createTakElement = function(taskString) {
    var listItem = document.createElement('li');
    var label = document.createElement('label');
    var checkBox = document.createElement('input');
    /*text box*/
    var editTextInput = document.createElement('input');
    /*edit and delete buttons*/
    var editButton = document.createElement('button');
    var deleteButton = document.createElement('button');


    checkBox.type = "checkbox";
    editTextInput.type = 'text';


    /*adding text to the label*/

    label.innerText = taskString;

    editButton.innerText = "Edit";
    editButton.className = "edit";

    deleteButton.innerText = "delete";
    deleteButton.className = "delete";

    /*as seen above all the elements are
     created now we have to append child elements to the listItem*/

     listItem.appendChild(checkBox);
     listItem.appendChild(label);
     listItem.appendChild(editTextInput);
     listItem.appendChild(editButton);
     listItem.appendChild(deleteButton);
     return listItem;
}

var addTask = function(){
	var listItem = createTakElement(taskInput.value);

	var incomplete = incompleteTaskHolder.appendChild(listItem)
    bindTaskEvents(listItem, taskcompleted);
	console.log(listItem)
}

addbutton.addEventListener('click', addTask);

var deleteTask = function(){
    console.log('delete')
    var listItem = this.parentNode;
    var ul = listItem.parentNode;

    ul.removeChild(listItem)
}

var taskIncomplete = function(){
    var listItem = this.parentNode;

    incompleteTaskHolder.appendChild(listItem);

    bindTaskEvents(listItem, taskcompleted)
}
var taskcompleted = function(){
       var listItem = this.parentNode;

    completeTaskHolder.appendChild(listItem);
    bindTaskEvents(listItem, taskIncomplete)
}

var editTask = function(){
    console.log('edit');

    var listItem = this.parentNode;

    var editInput = listItem.querySelector('input[type="text"]');

    var label = listItem.querySelector('label');

    var containsClass = listItem.classList.contains('editMode');

    if(containsClass){
        label.innerText = editInput.value;
    }
    else{
        editInput.value = label.innerText;
    }

    listItem.classList.toggle("editMode")


}

var bindTaskEvents = function(taskListItem, checkboxEvent){
    console.log('bind list item events');

    var checkBox = taskListItem.querySelector("input[type=checkbox]");
    var editButton = taskListItem.querySelector('button.edit');
    var deleteButton = taskListItem.querySelector('button.delete');

    deleteButton.onclick = deleteTask;


    /*check box functionality*/

    checkBox.onchange = checkboxEvent;

    editButton.onclick = editTask;

}

for (var i = 0;i<incompleteTaskHolder.children.length; i++){
    bindTaskEvents(incompleteTaskHolder.children[i], taskcompleted)
}

for (var i = 0;i<completeTaskHolder.children.length; i++){
    bindTaskEvents(completeTaskHolder.children[i], taskIncomplete)
}
