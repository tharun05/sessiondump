/*variables*/

var variable = 5;
console.log(typeof variable)

variable = 'tharun';
console.log(variable);

variable = 1.5;

console.log(typeof variable)

var item = undefined;

// console.log(typeof item);


// item = 10;

// console.log(item)

var empty = null;

console.log(empty === item)
// console.log(typeof empty)

// empty = 10;

// console.log(empty)


var num = NaN;

console.log(typeof num);

console.log('asdha'*5);


var arr = [1,2,3,4,'tharun', null, undefined];

console.log(typeof arr)

console.log(arr[4]);


function name(){
	console.log('function')
	var num= 10;
	console.log(num)
}

name();


var lync = function(){
	console.log('anonymos function')
}


console.log(lync);

var obj = {
	'name':'tharun'
}

console.log(obj.name);














